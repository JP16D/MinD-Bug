Have you ever thought its a hassle to re-install your mod just to change a few magical values? Or ever thought that it would be nice if you can monitor the value changes your math sorcery does?

Then say no more!

MinD-Bug aims to be the do it all debugger for mindustry mod making, giving you easy access to monitoring and changing values on the go while developing, to make it work simply follow the guides right here:

- [Applying Dependency]()
- [Value Debugger]()
- [Error Catcher]()

### Planned Features:
- Operators and Functions - on the go math sorcery for testing out stuffs
- Experimental Ragdoll - unit and block placholders for experimental designing of animations, parts, and behaviours of your custom units!
